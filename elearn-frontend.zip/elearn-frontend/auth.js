const API = "http://localhost:3000";

async function login(id, password) {
  const r = await fetch(`${API}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, password })
  });
  const data = await r.json();
  if (!data.ok) throw new Error(data.error || "Login failed");

  localStorage.setItem("token", data.token);
  localStorage.setItem("user", JSON.stringify(data.user));
  return data.user;
}

function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
}

function getUser() {
  const u = localStorage.getItem("user");
  return u ? JSON.parse(u) : null;
}

function getToken() {
  return localStorage.getItem("token");
}

window.ElearnAuth = { login, logout, getUser, getToken, API };
