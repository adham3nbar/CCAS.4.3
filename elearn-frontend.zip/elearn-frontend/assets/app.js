alert("app.js loaded");
document.addEventListener("DOMContentLoaded", () => {
  const loginBtn = document.getElementById("loginBtn");
  const emailEl = document.getElementById("email");
  const passEl = document.getElementById("password");
  const roleEl = document.getElementById("role"); // if exists
  const msg = document.getElementById("msg");

  const setMsg = (t) => { if (msg) msg.textContent = t || ""; };

  if (!loginBtn) return;

  loginBtn.addEventListener("click", async () => {
    try {
      setMsg("");

      const email = (emailEl?.value || "").trim().toLowerCase();
      const password = passEl?.value || "";
      const roleHint = roleEl?.value || "";

      if (!email || !password) return setMsg("Enter email + password.");

      const data = await API.login(email, password, roleHint);
      if (!data.ok) return setMsg(data.error || "Login failed.");

      API.saveSession({ ...data.session, demoMode: false });

      const s = API.getSession();
      if (s.role === "admin") location.href = "pages/admin.html";
      else if (s.role === "teacher") location.href = "pages/teacher.html";
      else location.href = "pages/student.html";
    } catch (e) {
      setMsg("API lost: " + (e.message || e));
    }
  });
});
