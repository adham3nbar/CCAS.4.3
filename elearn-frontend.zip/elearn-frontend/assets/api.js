// Make API a real global (so app.js can use: API.demoLogin(...))
var API = (function () {
  // ----------------------------
  // DEMO DATA (simple)
  // ----------------------------
  const demo = {
    admin: [{ admin_id: 1, name: "Admin", email: "admin@a.com", password: "123" }],
    students: [
      { student_id: 101, name: "Amr", email: "amr@s.com", password: "123" },
      { student_id: 102, name: "Yassin", email: "yassin@s.com", password: "123" },
      { student_id: 103, name: "Abdelhamid", email: "abdel@s.com", password: "123" },
      { student_id: 104, name: "Adham", email: "adham@s.com", password: "123" }
    ],
    teachers: [
      { teacher_id: 1, name: "Mr Amr", email: "amr@t.com", password: "123" },
      { teacher_id: 2, name: "Mr Yassin", email: "yassin@t.com", password: "123" },
      { teacher_id: 3, name: "Mr Abdelhamid", email: "abdel@t.com", password: "123" },
      { teacher_id: 4, name: "Mr Adham", email: "adham@t.com", password: "123" }
    ],
    courses: [
      { course_id: 201, title: "Databases", teacher_id: 1 },
      { course_id: 202, title: "Software Eng", teacher_id: 2 },
      { course_id: 203, title: "Web Dev", teacher_id: 3 },
      { course_id: 204, title: "Data Struct", teacher_id: 4 },
      { course_id: 205, title: "OS", teacher_id: 1 },
      { course_id: 206, title: "Networks", teacher_id: 2 }
    ],
    enrollments: [
      { student_id: 101, course_id: 201 },
      { student_id: 101, course_id: 202 },
      { student_id: 102, course_id: 203 },
      { student_id: 102, course_id: 204 },
      { student_id: 103, course_id: 205 },
      { student_id: 104, course_id: 206 }
    ],
    assessments: [
      { assessment_id: 301, course_id: 201, title: "Assignment 1", max_score: 100 },
      { assessment_id: 302, course_id: 202, title: "Quiz 1", max_score: 20 },
      { assessment_id: 303, course_id: 203, title: "Assignment 1", max_score: 100 },
      { assessment_id: 304, course_id: 205, title: "Quiz 1", max_score: 20 }
    ],
    submissions: [
      { submission_id: 401, assessment_id: 301, student_id: 101, submitted_at: "2026-01-01 10:00" },
      { submission_id: 402, assessment_id: 303, student_id: 102, submitted_at: "2026-01-01 11:00" }
    ],
    grades: [
      { submission_id: 401, teacher_id: 1, score: 95 },
      { submission_id: 402, teacher_id: 3, score: 88 }
    ]
  };

  // ----------------------------
  // BACKEND URL
  // ----------------------------
  const BASE_URL = "http://localhost:3000/api";

  // ----------------------------
  // Session helpers
  // ----------------------------
  function saveSession(session) {
    localStorage.setItem("session", JSON.stringify(session));
  }

  function getSession() {
    const s = localStorage.getItem("session");
    return s ? JSON.parse(s) : null;
  }

  function clearSession() {
    localStorage.removeItem("session");
  }

  // ----------------------------
  // DEMO helpers
  // ----------------------------
  function demoLogin(email, password, roleHint) {
    function match(arr, role) {
      const u = arr.find(x => x.email === email && x.password === password);
      return u ? { role, data: u } : null;
    }
    if (roleHint === "student") return match(demo.students, "student");
    if (roleHint === "teacher") return match(demo.teachers, "teacher");
    if (roleHint === "admin") return match(demo.admin, "admin");
    return match(demo.teachers, "teacher") || match(demo.students, "student") || match(demo.admin, "admin");
  }

  function demoStudentCourses(student_id) {
    const ids = demo.enrollments.filter(e => e.student_id === student_id).map(e => e.course_id);
    return demo.courses.filter(c => ids.includes(c.course_id));
  }

  function demoTeacherCourses(teacher_id) {
    return demo.courses.filter(c => c.teacher_id === teacher_id);
  }

  function demoCourseAssessments(course_id) {
    return demo.assessments.filter(a => a.course_id === course_id);
  }

  function demoStudentGrades(student_id) {
    const subs = demo.submissions.filter(s => s.student_id === student_id);
    return subs.map(s => {
      const a = demo.assessments.find(x => x.assessment_id === s.assessment_id);
      const c = demo.courses.find(x => x.course_id === a.course_id);
      const g = demo.grades.find(x => x.submission_id === s.submission_id);
      return { course: c.title, assessment: a.title, score: g ? g.score : null, max_score: a.max_score };
    });
  }

  function demoSubmit(student_id, assessment_id) {
    const exists = demo.submissions.find(s => s.student_id === student_id && s.assessment_id === assessment_id);
    if (exists) return { ok: false, error: "You already submitted this assessment." };

    const newId = (demo.submissions.reduce((m, s) => Math.max(m, s.submission_id), 400)) + 1;
    demo.submissions.push({
      submission_id: newId,
      student_id,
      assessment_id,
      submitted_at: new Date().toISOString().slice(0, 16).replace("T", " ")
    });
    return { ok: true, submission_id: newId };
  }

  function demoAssessmentSubmissions(assessment_id) {
    return demo.submissions
      .filter(s => s.assessment_id === assessment_id)
      .map(s => ({
        ...s,
        student_name: (demo.students.find(st => st.student_id === s.student_id) || {}).name || "Unknown"
      }));
  }

  function demoGradeSubmission(submission_id, teacher_id, score) {
    const existing = demo.grades.find(g => g.submission_id === submission_id);
    if (existing) existing.score = score;
    else demo.grades.push({ submission_id, teacher_id, score });
    return { ok: true };
  }

  function demoCreateCourse(title, teacher_id) {
    const newId = (demo.courses.reduce((m, c) => Math.max(m, c.course_id), 200)) + 1;
    demo.courses.push({ course_id: newId, title, teacher_id });
    return { ok: true, course_id: newId };
  }

  function demoCreateAssessment(course_id, title, max_score) {
    const newId = (demo.assessments.reduce((m, a) => Math.max(m, a.assessment_id), 300)) + 1;
    demo.assessments.push({ assessment_id: newId, course_id, title, max_score });
    return { ok: true, assessment_id: newId };
  }

  // ----------------------------
  // BACKEND HTTP helpers
  // ----------------------------
  async function apiPost(path, body) {
    const res = await fetch(`${BASE_URL}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {})
    });
    return res.json();
  }

  async function apiGet(path) {
    const res = await fetch(`${BASE_URL}${path}`);
    return res.json();
  }

  // ----------------------------
  // REAL DB API calls
  // ----------------------------
  async function login(email, password, roleHint) {
    return apiPost("/login", { email, password, roleHint });
  }

  async function getStudentCourses(student_id) {
    return apiGet(`/student/${student_id}/courses`);
  }

  async function getTeacherCourses(teacher_id) {
    return apiGet(`/teacher/${teacher_id}/courses`);
  }

  // Student feature endpoints
  async function getCourseAssessments(course_id) {
    return apiGet(`/course/${course_id}/assessments`);
  }

  async function getStudentGrades(student_id) {
    return apiGet(`/student/${student_id}/grades`);
  }

  async function submitAssignment(student_id, assessment_id) {
    return apiPost(`/submission`, { student_id, assessment_id });
  }

  // Teacher feature endpoints
  async function getTeacherCourseAssessments(teacher_id, course_id) {
    return apiGet(`/teacher/${teacher_id}/course/${course_id}/assessments`);
  }

  async function getAssessmentSubmissionsForTeacher(teacher_id, assessment_id) {
    return apiGet(`/teacher/${teacher_id}/assessment/${assessment_id}/submissions`);
  }

  async function gradeSubmission(teacher_id, submission_id, score) {
    return apiPost(`/teacher/${teacher_id}/grade`, { submission_id, score });
  }

  return {
    // session
    saveSession, getSession, clearSession,

    // demo
    demoLogin, demoStudentCourses, demoTeacherCourses, demoCourseAssessments,
    demoStudentGrades, demoSubmit, demoAssessmentSubmissions, demoGradeSubmission,
    demoCreateCourse, demoCreateAssessment,

    // backend low-level + real calls
    apiPost, apiGet,
    login, getStudentCourses, getTeacherCourses,

    // student (db)
    getCourseAssessments, getStudentGrades, submitAssignment,

    // teacher (db)
    getTeacherCourseAssessments, getAssessmentSubmissionsForTeacher, gradeSubmission
  };
})();

console.log("API ready", API);

