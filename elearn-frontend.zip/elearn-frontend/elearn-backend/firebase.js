const admin = require("firebase-admin");
const path = require("path");

// Service key file should be placed in this folder (NOT committed)
const serviceAccount = require(path.join(__dirname, "firebaseServiceKey.json"));

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();
module.exports = db;
