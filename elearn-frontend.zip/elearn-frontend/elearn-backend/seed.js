const db = require("./firebase");

async function clearCollection(name) {
  const snap = await db.collection(name).get();
  const batchSize = 400;
  let batch = db.batch();
  let i = 0;

  for (const doc of snap.docs) {
    batch.delete(doc.ref);
    i++;
    if (i % batchSize === 0) {
      await batch.commit();
      batch = db.batch();
    }
  }
  if (i % batchSize !== 0) await batch.commit();
}

async function main() {
  // Optional: wipe old seed data so reruns are clean
  await clearCollection("enrollments");
  await clearCollection("courses");
  await clearCollection("users");

  const PASSWORD = "123";

  // 4 students
  const students = [
    { id: "amr",    name: "Amr",    email: "amr@elearn.com",    role: "student", password: PASSWORD },
    { id: "bido",   name: "Bido",   email: "bido@elearn.com",   role: "student", password: PASSWORD },
    { id: "yassin", name: "Yassin", email: "yassin@elearn.com", role: "student", password: PASSWORD },
    { id: "adham",  name: "Adham",  email: "adham@elearn.com",  role: "student", password: PASSWORD },
  ];

  // 4 teachers
  const teachers = [
    { id: "mramr",    name: "Mr Amr",    email: "mramr@elearn.com",    role: "teacher", password: PASSWORD },
    { id: "mrbido",   name: "Mr Bido",   email: "mrbido@elearn.com",   role: "teacher", password: PASSWORD },
    { id: "mryassin", name: "Mr Yassin", email: "mryassin@elearn.com", role: "teacher", password: PASSWORD },
    { id: "mradham",  name: "Mr Adham",  email: "mradham@elearn.com",  role: "teacher", password: PASSWORD },
  ];

  // 1 admin
  const admin = [
    { id: "admin", name: "Admin", email: "admin@elearn.com", role: "admin", password: PASSWORD },
  ];

  const users = [...students, ...teachers, ...admin];

  // Each teacher gives 2 courses => 8 total
  const courses = [
    { id: "AMR101", title: "Amr Course 1", teacherId: "mramr" },
    { id: "AMR102", title: "Amr Course 2", teacherId: "mramr" },

    { id: "BID101", title: "Bido Course 1", teacherId: "mrbido" },
    { id: "BID102", title: "Bido Course 2", teacherId: "mrbido" },

    { id: "YAS101", title: "Yassin Course 1", teacherId: "mryassin" },
    { id: "YAS102", title: "Yassin Course 2", teacherId: "mryassin" },

    { id: "ADH101", title: "Adham Course 1", teacherId: "mradham" },
    { id: "ADH102", title: "Adham Course 2", teacherId: "mradham" },
  ];

  // Write users (doc id = user id)
  for (const u of users) {
    await db.collection("users").doc(u.id).set(u);
  }

  // Write courses (doc id = course id)
  for (const c of courses) {
    await db.collection("courses").doc(c.id).set(c);
  }

  // Enroll each student in all 8 courses
  for (const s of students) {
    for (const c of courses) {
      await db.collection("enrollments").add({
        studentId: s.id,
        courseId: c.id,
      });
    }
  }

  console.log("✅ Seed complete:");
  console.log(`- Users: ${users.length} (students ${students.length}, teachers ${teachers.length}, admin ${admin.length})`);
  console.log(`- Courses: ${courses.length}`);
  console.log(`- Enrollments: ${students.length * courses.length}`);
}

main().catch((e) => {
  console.error("❌ Seed failed:", e);
  process.exit(1);
});
