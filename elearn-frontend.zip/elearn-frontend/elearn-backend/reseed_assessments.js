const db = require("./firebase");

async function clearCollection(name) {
  const snap = await db.collection(name).get();
  if (snap.empty) return;
  const batch = db.batch();
  snap.docs.forEach(d => batch.delete(d.ref));
  await batch.commit();
}

async function main() {
  // wipe old assessments + submissions (fresh demo)
  await clearCollection("submissions");
  await clearCollection("assessments");

  // read all courses
  const courseSnap = await db.collection("courses").get();
  const courses = courseSnap.docs.map(d => ({ id: d.id, ...d.data() }));

  let count = 0;
  for (const c of courses) {
    const a1 = {
      assessment_id: `${c.id}_A1`,
      course_id: c.id,
      title: "Assignment 1",
      max_score: 100,
      teacherId: c.teacherId,
    };
    const a2 = {
      assessment_id: `${c.id}_A2`,
      course_id: c.id,
      title: "Assignment 2",
      max_score: 100,
      teacherId: c.teacherId,
    };

    await db.collection("assessments").doc(a1.assessment_id).set(a1);
    await db.collection("assessments").doc(a2.assessment_id).set(a2);
    count += 2;
  }

  console.log(`✅ Seeded ${count} assessments (${courses.length} courses × 2)`);
}

main().catch(e => { console.error("❌", e); process.exit(1); });
