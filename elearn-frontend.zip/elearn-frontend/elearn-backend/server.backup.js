const express = require("express");
const cors = require("cors");
const db = require("./firebase");

const app = express();
app.use(cors());
app.use(express.json());

// -------------------- AUTH (simple for project demo) --------------------
// NOTE: This is not production auth. It’s a simple login for your coursework/demo.
// It returns a token stored in memory (no refresh, no JWT). Easy for teammates.

const tokens = new Map(); // token -> { id, role }

function makeToken() {
  return Math.random().toString(16).slice(2) + Date.now().toString(16);
}

function requireAuth(req, res, next) {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token || !tokens.has(token)) return res.status(401).json({ ok: false, error: "Unauthorized" });
  req.user = tokens.get(token);
  next();
}

function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== "admin") return res.status(403).json({ ok: false, error: "Admin only" });
  next();
}

// Login: { id, password }
app.post("/login", async (req, res) => {
  try {
    const { id, password } = req.body || {};
    if (!id || !password) return res.status(400).json({ ok: false, error: "Missing id/password" });

    const userDoc = await db.collection("users").doc(id).get();
    if (!userDoc.exists) return res.status(401).json({ ok: false, error: "Invalid credentials" });

    const user = userDoc.data();
    if (user.password !== password) return res.status(401).json({ ok: false, error: "Invalid credentials" });

    const token = makeToken();
    tokens.set(token, { id: user.id, role: user.role });

    // send minimal info
    return res.json({
      ok: true,
      token,
      user: { id: user.id, name: user.name, role: user.role, email: user.email },
    });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message });
  }
});

// -------------------- STUDENT COURSES --------------------
app.get("/student/:id/courses", async (req, res) => {
  try {
    const studentId = req.params.id;

    // enrollments where studentId == X
    const enrollSnap = await db.collection("enrollments")
      .where("studentId", "==", studentId)
      .get();

    const courseIds = enrollSnap.docs.map(d => d.data().courseId);

    const courses = [];
    for (const cid of courseIds) {
      const cdoc = await db.collection("courses").doc(cid).get();
      if (cdoc.exists) courses.push({ id: cid, ...cdoc.data() });
    }

    return res.json({ ok: true, studentId, count: courses.length, courses });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message });
  }
});

// -------------------- TEACHER COURSES --------------------
app.get("/teacher/:id/courses", async (req, res) => {
  try {
    const teacherId = req.params.id;

    const snap = await db.collection("courses")
      .where("teacherId", "==", teacherId)
      .get();

    const courses = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    return res.json({ ok: true, teacherId, count: courses.length, courses });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message });
  }
});

// -------------------- ADMIN (protected) --------------------
app.delete("/admin/users/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    const userId = req.params.id;

    // delete user
    await db.collection("users").doc(userId).delete();

    // delete enrollments for that student (if any)
    const enrollSnap = await db.collection("enrollments").where("studentId", "==", userId).get();
    const batch = db.batch();
    enrollSnap.docs.forEach(d => batch.delete(d.ref));
    if (!enrollSnap.empty) await batch.commit();

    return res.json({ ok: true, deletedUser: userId, deletedEnrollments: enrollSnap.size });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message });
  }
});

app.delete("/admin/courses/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    const courseId = req.params.id;

    // delete course doc
    await db.collection("courses").doc(courseId).delete();

    // delete enrollments for that course
    const snap = await db.collection("enrollments").where("courseId", "==", courseId).get();
    const batch = db.batch();
    snap.docs.forEach(d => batch.delete(d.ref));
    if (!snap.empty) await batch.commit();

    return res.json({ ok: true, deletedCourse: courseId, deletedEnrollments: snap.size });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message });
  }
});

// -------------------- HEALTH --------------------
app.get("/health", (req, res) => res.json({ ok: true }));

app.listen(3000, () => console.log("API running on http://localhost:3000 (Firebase)"));
