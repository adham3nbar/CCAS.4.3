require("dotenv").config();

const oracledb = require("oracledb");

// ✅ Enable Thick mode (required for Oracle FreeSQL encryption negotiation)
try {
  oracledb.initOracleClient({ libDir: process.env.OCI_LIB_DIR });
  console.log("✅ Oracle Thick mode enabled");
} catch (e) {
  console.error("❌ Thick mode failed:", e.message);
}

const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());
// ADMIN: delete any user
app.delete("/admin/users/:id", async (req, res) => {
  try {
    const userId = req.params.id;
    await db.collection("users").doc(userId).delete();
    res.json({ ok: true, deletedUser: userId });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// ADMIN: delete any course + related enrollments
app.delete("/admin/courses/:id", async (req, res) => {
  try {
    const courseId = req.params.id;

    // delete course doc
    await db.collection("courses").doc(courseId).delete();

    // delete enrollments for that course
    const snap = await db.collection("enrollments").where("courseId", "==", courseId).get();
    const batch = db.batch();
    snap.docs.forEach(d => batch.delete(d.ref));
    await batch.commit();

    res.json({ ok: true, deletedCourse: courseId, deletedEnrollments: snap.size });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

async function getConn() {
  return oracledb.getConnection({
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING,
  });
}

// ---------- HEALTH ----------
app.get("/api/health", async (req, res) => {
  let conn;
  try {
    conn = await getConn();
    const r = await conn.execute(
      `SELECT 'OK' AS status FROM dual`,
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );
    res.json({ ok: true, db: r.rows[0].STATUS });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  } finally {
    if (conn) {
      try { await conn.close(); } catch {}
    }
  }
});

// ---------- LOGIN ----------
app.post("/api/login", async (req, res) => {
  const { email, password, roleHint } = req.body || {};

  if (!email || !password) {
    return res.json({ ok: false, error: "Email and password required" });
  }

  const checks = {
    student: {
      role: "student",
      sql: `SELECT student_id, name, email FROM student WHERE email=:email AND password=:password`,
    },
    teacher: {
      role: "teacher",
      sql: `SELECT teacher_id, name, email FROM teacher WHERE email=:email AND password=:password`,
    },
    admin: {
      role: "admin",
      sql: `SELECT admin_id, name, email FROM admin WHERE email=:email AND password=:password`,
    },
  };

  const order = roleHint ? [roleHint] : ["teacher", "student", "admin"];

  let conn;
  try {
    conn = await getConn();

    for (const k of order) {
      const q = checks[k];
      if (!q) continue;

      const r = await conn.execute(
        q.sql,
        { email, password },
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      );

      if (r.rows && r.rows.length) {
        const u = r.rows[0];

        let session;
        if (q.role === "student") {
          session = { role: "student", student_id: u.STUDENT_ID, name: u.NAME, email: u.EMAIL };
        } else if (q.role === "teacher") {
          session = { role: "teacher", teacher_id: u.TEACHER_ID, name: u.NAME, email: u.EMAIL };
        } else {
          session = { role: "admin", admin_id: u.ADMIN_ID, name: u.NAME, email: u.EMAIL };
        }

        return res.json({ ok: true, session });
      }
    }

    return res.json({ ok: false, error: "Invalid credentials" });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message });
  } finally {
    if (conn) {
      try { await conn.close(); } catch {}
    }
  }
});

// ---------- STUDENT COURSES ----------
app.get("/api/student/:student_id/courses", async (req, res) => {
  const student_id = Number(req.params.student_id);

  const sql = `
    SELECT c.course_id, c.title
    FROM course c
    JOIN enrollment e ON e.course_id = c.course_id
    WHERE e.student_id = :student_id
    ORDER BY c.course_id
  `;

  let conn;
  try {
    conn = await getConn();
    const r = await conn.execute(sql, { student_id }, { outFormat: oracledb.OUT_FORMAT_OBJECT });
    res.json({ ok: true, courses: r.rows });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  } finally {
    if (conn) {
      try { await conn.close(); } catch {}
    }
  }
});

// ---------- TEACHER COURSES ----------
app.get("/api/teacher/:teacher_id/courses", async (req, res) => {
  const teacher_id = Number(req.params.teacher_id);

  const sql = `
    SELECT course_id, title
    FROM course
    WHERE teacher_id = :teacher_id
    ORDER BY course_id
  `;

  let conn;
  try {
    conn = await getConn();
    const r = await conn.execute(sql, { teacher_id }, { outFormat: oracledb.OUT_FORMAT_OBJECT });
    res.json({ ok: true, courses: r.rows });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  } finally {
    if (conn) {
      try { await conn.close(); } catch {}
    }
  }
});


// ---------- COURSE ASSESSMENTS ----------
app.get("/api/course/:course_id/assessments", async (req, res) => {
  const course_id = Number(req.params.course_id);
  const sql = `
    SELECT assessment_id, title, max_score
    FROM assessment
    WHERE course_id = :course_id
    ORDER BY assessment_id
  `;

  let conn;
  try {
    conn = await getConn();
    const r = await conn.execute(sql, { course_id }, { outFormat: oracledb.OUT_FORMAT_OBJECT });
    res.json({ ok: true, assessments: r.rows });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  } finally {
    if (conn) await conn.close();
  }
});

// ---------- STUDENT GRADES ----------
app.get("/api/student/:student_id/grades", async (req, res) => {
  const student_id = Number(req.params.student_id);
  const sql = `
    SELECT
      c.title AS course_title,
      a.title AS assessment_title,
      a.max_score,
      g.score
    FROM submission s
    JOIN assessment a ON a.assessment_id = s.assessment_id
    JOIN course c ON c.course_id = a.course_id
    LEFT JOIN grade g ON g.submission_id = s.submission_id
    WHERE s.student_id = :student_id
    ORDER BY c.course_id, a.assessment_id
  `;

  let conn;
  try {
    conn = await getConn();
    const r = await conn.execute(sql, { student_id }, { outFormat: oracledb.OUT_FORMAT_OBJECT });
    res.json({ ok: true, grades: r.rows });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  } finally {
    if (conn) await conn.close();
  }
});

// ---------- SUBMIT ASSIGNMENT ----------
app.post("/api/submission", async (req, res) => {
  const { student_id, assessment_id } = req.body;
  const sid = Number(student_id);
  const aid = Number(assessment_id);

  let conn;
  try {
    conn = await getConn();

    const check = await conn.execute(
      `SELECT COUNT(*) AS CNT FROM submission WHERE student_id=:sid AND assessment_id=:aid`,
      { sid, aid },
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );

    if (check.rows[0].CNT > 0) {
      return res.json({ ok: false, error: "Already submitted" });
    }

    const mx = await conn.execute(
      `SELECT NVL(MAX(submission_id),0) AS MX FROM submission`,
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );

    const newId = mx.rows[0].MX + 1;

    await conn.execute(
      `INSERT INTO submission (submission_id, submitted_at, student_id, assessment_id)
       VALUES (:id, SYSTIMESTAMP, :sid, :aid)`,
      { id: newId, sid, aid },
      { autoCommit: true }
    );

    res.json({ ok: true, submission_id: newId });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  } finally {
    if (conn) await conn.close();
  }
});


// ---------- TEACHER: COURSE ASSESSMENTS ----------
app.get("/api/teacher/:teacher_id/course/:course_id/assessments", async (req, res) => {
  const teacher_id = Number(req.params.teacher_id);
  const course_id = Number(req.params.course_id);

  const sql = `
    SELECT a.assessment_id, a.title, a.max_score
    FROM assessment a
    JOIN course c ON c.course_id = a.course_id
    WHERE a.course_id = :course_id
      AND c.teacher_id = :teacher_id
    ORDER BY a.assessment_id
  `;

  let conn;
  try {
    conn = await getConn();
    const r = await conn.execute(sql, { course_id, teacher_id }, { outFormat: oracledb.OUT_FORMAT_OBJECT });
    res.json({ ok: true, assessments: r.rows });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  } finally {
    if (conn) { try { await conn.close(); } catch {} }
  }
});

// ---------- TEACHER: VIEW SUBMISSIONS FOR AN ASSESSMENT ----------
app.get("/api/teacher/:teacher_id/assessment/:assessment_id/submissions", async (req, res) => {
  const teacher_id = Number(req.params.teacher_id);
  const assessment_id = Number(req.params.assessment_id);

  const sql = `
    SELECT
      s.submission_id,
      s.submitted_at,
      st.student_id,
      st.name AS student_name,
      g.score
    FROM submission s
    JOIN student st ON st.student_id = s.student_id
    JOIN assessment a ON a.assessment_id = s.assessment_id
    JOIN course c ON c.course_id = a.course_id
    LEFT JOIN grade g ON g.submission_id = s.submission_id
    WHERE s.assessment_id = :assessment_id
      AND c.teacher_id = :teacher_id
    ORDER BY s.submission_id
  `;

  let conn;
  try {
    conn = await getConn();
    const r = await conn.execute(sql, { assessment_id, teacher_id }, { outFormat: oracledb.OUT_FORMAT_OBJECT });
    res.json({ ok: true, submissions: r.rows });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  } finally {
    if (conn) { try { await conn.close(); } catch {} }
  }
});

// ---------- TEACHER: GRADE A SUBMISSION (INSERT/UPDATE) ----------
app.post("/api/teacher/:teacher_id/grade", async (req, res) => {
  const teacher_id = Number(req.params.teacher_id);
  const { submission_id, score } = req.body || {};
  const subId = Number(submission_id);
  const sc = Number(score);

  if (!subId || Number.isNaN(sc)) {
    return res.json({ ok: false, error: "submission_id and numeric score required" });
  }

  let conn;
  try {
    conn = await getConn();

    // Ensure submission belongs to a course taught by this teacher
    const owns = await conn.execute(
      `
      SELECT COUNT(*) AS CNT
      FROM submission s
      JOIN assessment a ON a.assessment_id = s.assessment_id
      JOIN course c ON c.course_id = a.course_id
      WHERE s.submission_id = :subId
        AND c.teacher_id = :teacher_id
      `,
      { subId, teacher_id },
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );

    if (owns.rows[0].CNT === 0) {
      return res.json({ ok: false, error: "Not allowed for this teacher." });
    }

    // Upsert grade
    const exists = await conn.execute(
      `SELECT COUNT(*) AS CNT FROM grade WHERE submission_id = :subId`,
      { subId },
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );

    if (exists.rows[0].CNT > 0) {
      await conn.execute(
        `UPDATE grade SET teacher_id = :teacher_id, score = :sc WHERE submission_id = :subId`,
        { teacher_id, sc, subId },
        { autoCommit: true }
      );
    } else {
      await conn.execute(
        `INSERT INTO grade (submission_id, teacher_id, score) VALUES (:subId, :teacher_id, :sc)`,
        { subId, teacher_id, sc },
        { autoCommit: true }
      );
    }

    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  } finally {
    if (conn) { try { await conn.close(); } catch {} }
  }
});


app.listen(process.env.PORT || 3000, () => {
  console.log(`API running on http://localhost:${process.env.PORT || 3000}`);
});

