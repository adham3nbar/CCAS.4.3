const db = require("./firebase");

async function clearCollection(name) {
  const snap = await db.collection(name).get();
  if (snap.empty) return;

  const batchSize = 400;
  let batch = db.batch();
  let i = 0;

  for (const doc of snap.docs) {
    batch.delete(doc.ref);
    i++;
    if (i % batchSize === 0) {
      await batch.commit();
      batch = db.batch();
    }
  }
  if (i % batchSize !== 0) await batch.commit();
}

async function main() {
  // Clear old data
  await clearCollection("enrollments");
  await clearCollection("courses");

  // Teachers (your seeded IDs)
  const T = {
    mramr: "mramr",
    mryassin: "mryassin",
    mrbido: "mrbido",
    mradham: "mradham",
  };

  // ✅ Realistic course titles (edit if you want)
  const courses = [
    // Mr Amr
    { id: "CS101",  title: "Introduction to Programming", teacherId: T.mramr },
    { id: "CS205",  title: "Data Structures",             teacherId: T.mramr },

    // Mr Yassin
    { id: "DB201",  title: "Database Systems",            teacherId: T.mryassin },
    { id: "SE220",  title: "Software Engineering",        teacherId: T.mryassin },

    // Mr Bido
    { id: "NW210",  title: "Computer Networks",           teacherId: T.mrbido },
    { id: "OS230",  title: "Operating Systems",           teacherId: T.mrbido },

    // Mr Adham
    { id: "WD150",  title: "Web Development Fundamentals",teacherId: T.mradham },
    { id: "AI240",  title: "Introduction to AI",          teacherId: T.mradham },
  ];

  // Write courses
  for (const c of courses) {
    await db.collection("courses").doc(c.id).set(c);
  }

  // Students (your seeded IDs)
  const students = ["amr", "bido", "yassin", "adham"];

  // Enroll each student in all courses
  for (const s of students) {
    for (const c of courses) {
      await db.collection("enrollments").add({
        studentId: s,
        courseId: c.id,
      });
    }
  }

  console.log("✅ Reseed done");
  console.log("Courses:", courses.length);
  console.log("Enrollments:", students.length * courses.length);
}

main().catch((e) => {
  console.error("❌ Error:", e);
  process.exit(1);
});
