const express = require("express");
const cors = require("cors");
const db = require("./firebase");

const app = express();

app.use(cors());
app.use(express.json());

const API = "/api";

// ===== CORS (allow frontend on different port) =====
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(200);
  next();
});

// ✅ Login by EMAIL
app.post(`${API}/login`, async (req, res) => {
  try {
    const { email, password, roleHint } = req.body || {};
    if (!email || !password) return res.json({ ok: false, error: "Missing email/password" });

    const e = String(email).trim().toLowerCase();

    const snap = await db.collection("users").where("email", "==", e).limit(1).get();
    if (snap.empty) return res.json({ ok: false, error: "User not found" });

    const doc = snap.docs[0];
    const user = doc.data();

    if (user.password !== password) return res.json({ ok: false, error: "Invalid credentials" });

    const role = user.role;
    const session = { role, name: user.name, email: user.email };

    if (role === "student") session.student_id = doc.id;
    if (role === "teacher") session.teacher_id = doc.id;
    if (role === "admin") session.admin_id = doc.id;

    if (roleHint && roleHint !== role) {
      return res.json({ ok: false, error: `Role mismatch. You are ${role}.` });
    }

    return res.json({ ok: true, session });
  } catch (e) {
    return res.json({ ok: false, error: e.message });
  }
});

// Student courses
app.get(`${API}/student/:sid/courses`, async (req, res) => {
  try {
    const studentId = req.params.sid;

    const enrollSnap = await db.collection("enrollments").where("studentId", "==", studentId).get();
    const courseIds = enrollSnap.docs.map(d => d.data().courseId);

    const courses = [];
    for (const cid of courseIds) {
      const cdoc = await db.collection("courses").doc(cid).get();
      if (cdoc.exists) courses.push({ course_id: cid, title: cdoc.data().title });
    }

    return res.json({ ok: true, courses });
  } catch (e) {
    return res.json({ ok: false, error: e.message });
  }
});

// Teacher courses
app.get(`${API}/teacher/:tid/courses`, async (req, res) => {
  try {
    const teacherId = req.params.tid;

    const snap = await db.collection("courses").where("teacherId", "==", teacherId).get();
    const courses = snap.docs.map(d => ({ course_id: d.id, title: d.data().title }));

    return res.json({ ok: true, courses });
  } catch (e) {
    return res.json({ ok: false, error: e.message });
  }
});

app.get("/health", (req, res) => res.json({ ok: true }));

// ===== ADMIN (Firebase) =====

// list all users
app.get(`${API}/admin/users`, async (req, res) => {
  try {
    const snap = await db.collection("users").get();
    const users = snap.docs.map(d => ({ docId: d.id, ...d.data() }));
    res.json({ ok: true, users });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// list all courses
app.get(`${API}/admin/courses`, async (req, res) => {
  try {
    const snap = await db.collection("courses").get();
    const courses = snap.docs.map(d => ({ course_id: d.id, ...d.data() }));
    res.json({ ok: true, courses });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// create course
app.post(`${API}/admin/courses`, async (req, res) => {
  try {
    const { course_id, title, teacherId } = req.body || {};
    if (!title || !teacherId) return res.json({ ok: false, error: "Missing title/teacherId" });

    const id = course_id && String(course_id).trim()
      ? String(course_id).trim()
      : "C" + Date.now();

    await db.collection("courses").doc(id).set({ title, teacherId });

    res.json({ ok: true, course_id: id });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// delete a course (and its enrollments)
app.delete(`${API}/admin/courses/:id`, async (req, res) => {
  try {
    const id = req.params.id;

    await db.collection("courses").doc(id).delete();

    const en = await db.collection("enrollments").where("courseId", "==", id).get();
    const batch = db.batch();
    en.docs.forEach(d => batch.delete(d.ref));
    await batch.commit();

    res.json({ ok: true, deletedCourse: id, deletedEnrollments: en.size });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// delete a user (and their enrollments as student)
app.delete(`${API}/admin/users/:id`, async (req, res) => {
  try {
    const id = req.params.id;

    await db.collection("users").doc(id).delete();

    const en = await db.collection("enrollments").where("studentId", "==", id).get();
    const batch = db.batch();
    en.docs.forEach(d => batch.delete(d.ref));
    await batch.commit();

    res.json({ ok: true, deletedUser: id, deletedEnrollments: en.size });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// ===== ASSESSMENTS / SUBMISSIONS / GRADES (Firebase) =====

// Course assessments (student view)
app.get(`${API}/course/:cid/assessments`, async (req, res) => {
  try {
    const cid = String(req.params.cid || "").trim();
    const snap = await db.collection("assessments").where("course_id", "==", cid).get();

    console.log("✅ /course/:cid/assessments  cid =", JSON.stringify(cid), " count =", snap.size);

    const assessments = snap.docs.map(d => d.data());
    res.json({ ok: true, cid, count: snap.size, assessments });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// Teacher course assessments
app.get(`${API}/teacher/:tid/course/:cid/assessments`, async (req, res) => {
  try {
    const tid = req.params.tid;
    const cid = req.params.cid;
    const snap = await db.collection("assessments")
      .where("course_id", "==", cid)
      .where("teacherId", "==", tid)
      .get();
    const assessments = snap.docs.map(d => d.data());
    res.json({ ok: true, assessments });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// ✅ Student submit (REAL route)
app.post(`${API}/submission`, async (req, res) => {
  try {
    const { student_id, assessment_id } = req.body || {};
    if (!student_id || !assessment_id) return res.json({ ok: false, error: "Missing student_id/assessment_id" });

    // prevent duplicate submit
    const existing = await db.collection("submissions")
      .where("student_id", "==", student_id)
      .where("assessment_id", "==", assessment_id)
      .limit(1)
      .get();
    if (!existing.empty) return res.json({ ok: false, error: "You already submitted this assessment." });

    const aDoc = await db.collection("assessments").doc(assessment_id).get();
    if (!aDoc.exists) return res.json({ ok: false, error: "Assessment not found." });

    const a = aDoc.data();

    const subRef = await db.collection("submissions").add({
      submission_id: "",
      assessment_id,
      course_id: a.course_id,
      teacherId: a.teacherId,
      student_id,
      submitted_at: new Date().toISOString(),
      score: null,
      graded_by: null,
    });

    await subRef.update({ submission_id: subRef.id });

    res.json({ ok: true, submission_id: subRef.id });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// Teacher sees submissions for assessment
app.get(`${API}/teacher/:tid/assessment/:aid/submissions`, async (req, res) => {
  try {
    const tid = req.params.tid;
    const aid = req.params.aid;

    const snap = await db.collection("submissions")
      .where("assessment_id", "==", aid)
      .where("teacherId", "==", tid)
      .get();

    const submissions = [];
    for (const d of snap.docs) {
      const s = d.data();
      const u = await db.collection("users").doc(s.student_id).get();
      submissions.push({
        submission_id: d.id,
        student_name: u.exists ? u.data().name : s.student_id,
        submitted_at: s.submitted_at,
        score: s.score,
      });
    }

    res.json({ ok: true, submissions });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// Teacher grades a submission
app.post(`${API}/teacher/:tid/grade`, async (req, res) => {
  try {
    const tid = req.params.tid;
    const { submission_id, score } = req.body || {};
    if (!submission_id || score === undefined || score === null) {
      return res.json({ ok: false, error: "Missing submission_id/score" });
    }

    await db.collection("submissions").doc(submission_id).update({
      score: Number(score),
      graded_by: tid,
    });

    res.json({ ok: true });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

// ✅ Student grades page (REAL route)
app.get(`${API}/student/:sid/grades`, async (req, res) => {
  try {
    const sid = req.params.sid;

    const snap = await db.collection("submissions").where("student_id", "==", sid).get();

    const grades = [];
    for (const d of snap.docs) {
      const sub = d.data();
      const aDoc = await db.collection("assessments").doc(sub.assessment_id).get();
      if (!aDoc.exists) continue;
      const a = aDoc.data();

      const cDoc = await db.collection("courses").doc(a.course_id).get();
      const courseTitle = cDoc.exists ? cDoc.data().title : a.course_id;

      grades.push({
        course: courseTitle,
        assessment: a.title,
        score: sub.score,
        max_score: a.max_score,
      });
    }

    res.json({ ok: true, grades });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

app.listen(3000, () => console.log("API running on http://localhost:3000 (Firebase, email login)"));

