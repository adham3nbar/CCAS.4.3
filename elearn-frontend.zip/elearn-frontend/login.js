document.addEventListener("DOMContentLoaded", () => {
  const emailEl = document.getElementById("email");
  const passEl = document.getElementById("password");
  const btn = document.getElementById("loginBtn");

  if (!emailEl || !passEl || !btn) {
    console.error("Login elements not found");
    return;
  }

  async function doLogin() {
    const email = (emailEl.value || "").trim().toLowerCase();
    const password = passEl.value || "";

    // Your Firestore users use ids like: amr, bido, yassin, adham, admin...
    // The UI uses email, so we map email -> id using the part before @
    const id = email.includes("@") ? email.split("@")[0] : email;

    try {
      const user = await ElearnAuth.login(id, password);

      // Optional: store role for UI logic
      localStorage.setItem("role", user.role);

      // Redirect based on role (edit these pages to match your project)
      if (user.role === "admin") {
        window.location.href = "pages/admin.html";
      } else if (user.role === "teacher") {
        window.location.href = "pages/teacher.html";
      } else {
        window.location.href = "pages/student.html";
      }
} catch (e) {
  alert(e.message || "Login failed");
}
}
  btn.addEventListener("click", doLogin);

  // Press Enter to login
  passEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter") doLogin();
  });
});
