document.addEventListener("DOMContentLoaded", () => {
  const user = ElearnAuth.getUser();
  if (!user) {
    alert("Please login first.");
    window.location.href = "../index.html";
    return;
  }
  if (user.role !== "admin") {
    alert("Admins only.");
    window.location.href = "student.html";
    return;
  }

  const delUserBtn = document.getElementById("delUserBtn");
  const delCourseBtn = document.getElementById("delCourseBtn");
  const userIdEl = document.getElementById("delUserId");
  const courseIdEl = document.getElementById("delCourseId");

  async function adminDeleteUser(userId) {
    const token = ElearnAuth.getToken();
    const r = await fetch(`${ElearnAuth.API}/admin/users/${encodeURIComponent(userId)}`, {
      method: "DELETE",
      headers: { "Authorization": `Bearer ${token}` }
    });
    const data = await r.json();
    if (!data.ok) throw new Error(data.error || "Delete user failed");
    return data;
  }

  async function adminDeleteCourse(courseId) {
    const token = ElearnAuth.getToken();
    const r = await fetch(`${ElearnAuth.API}/admin/courses/${encodeURIComponent(courseId)}`, {
      method: "DELETE",
      headers: { "Authorization": `Bearer ${token}` }
    });
    const data = await r.json();
    if (!data.ok) throw new Error(data.error || "Delete course failed");
    return data;
  }

  if (delUserBtn && userIdEl) {
    delUserBtn.addEventListener("click", async () => {
      try {
        const id = (userIdEl.value || "").trim();
        if (!id) return alert("Enter user id (e.g. amr, admin, mramr)");
        const out = await adminDeleteUser(id);
        alert(`Deleted user ${out.deletedUser} (removed enrollments: ${out.deletedEnrollments || 0})`);
      } catch (e) {
        alert(e.message);
      }
    });
  }

  if (delCourseBtn && courseIdEl) {
    delCourseBtn.addEventListener("click", async () => {
      try {
        const id = (courseIdEl.value || "").trim();
        if (!id) return alert("Enter course id (e.g. AMR101)");
        const out = await adminDeleteCourse(id);
        alert(`Deleted course ${out.deletedCourse} (removed enrollments: ${out.deletedEnrollments || 0})`);
      } catch (e) {
        alert(e.message);
      }
    });
  }
});
